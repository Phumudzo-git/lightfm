try:
    __LIGHTFM_SETUP__
except NameError:
    from .lightFM_model import LightFM

__version__ = "1.16"

__all__ = ["LightFM", "datasets", "evaluation"]
